﻿namespace dashboard.PL
{
    partial class frmMatches
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pnl1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblBeastOf = new System.Windows.Forms.Label();
            this.lblMatchNumber = new System.Windows.Forms.Label();
            this.lblReferee = new System.Windows.Forms.Label();
            this.lblScorer = new System.Windows.Forms.Label();
            this.lblLineJudges1 = new System.Windows.Forms.Label();
            this.lblDivision = new System.Windows.Forms.Label();
            this.lblMatchDate = new System.Windows.Forms.Label();
            this.lblMatchTime = new System.Windows.Forms.Label();
            this.lblLineJudges2 = new System.Windows.Forms.Label();
            this.lblLineJudges3 = new System.Windows.Forms.Label();
            this.lblLineJudges4 = new System.Windows.Forms.Label();
            this.lblDateSaved = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.pnl3 = new System.Windows.Forms.Panel();
            this.lblTeamBResult = new System.Windows.Forms.Label();
            this.lblTeamBTimeout5 = new System.Windows.Forms.Label();
            this.lblTeamBTimeout4 = new System.Windows.Forms.Label();
            this.lblTeamBTimeout3 = new System.Windows.Forms.Label();
            this.lblTeamBTimeout2 = new System.Windows.Forms.Label();
            this.lblTeamBTimeout1 = new System.Windows.Forms.Label();
            this.lblTeamBSet5 = new System.Windows.Forms.Label();
            this.lblTeamBSet4 = new System.Windows.Forms.Label();
            this.lblTeamBSet3 = new System.Windows.Forms.Label();
            this.lblTeamBSet2 = new System.Windows.Forms.Label();
            this.lblTeamBSet1 = new System.Windows.Forms.Label();
            this.lblTeamBCoach = new System.Windows.Forms.Label();
            this.lblTeamBName = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.pnl2 = new System.Windows.Forms.Panel();
            this.lblTeamAResult = new System.Windows.Forms.Label();
            this.lblTeamATimeout5 = new System.Windows.Forms.Label();
            this.lblTeamATimeout4 = new System.Windows.Forms.Label();
            this.lblTeamATimeout3 = new System.Windows.Forms.Label();
            this.lblTeamATimeout2 = new System.Windows.Forms.Label();
            this.lblTeamATimeout1 = new System.Windows.Forms.Label();
            this.lblTeamASet5 = new System.Windows.Forms.Label();
            this.lblTeamASet4 = new System.Windows.Forms.Label();
            this.lblTeamASet3 = new System.Windows.Forms.Label();
            this.lblTeamASet2 = new System.Windows.Forms.Label();
            this.lblTeamASet1 = new System.Windows.Forms.Label();
            this.lblTeamACoach = new System.Windows.Forms.Label();
            this.lblTeamAName = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnDelete = new System.Windows.Forms.Button();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.pnl1.SuspendLayout();
            this.pnl3.SuspendLayout();
            this.pnl2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semilight", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label2.Location = new System.Drawing.Point(18, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 32);
            this.label2.TabIndex = 16;
            this.label2.Text = "Matches";
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.dgv);
            this.pnlMain.Controls.Add(this.label6);
            this.pnlMain.Controls.Add(this.txtSearch);
            this.pnlMain.Controls.Add(this.panel6);
            this.pnlMain.Location = new System.Drawing.Point(24, 81);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1070, 580);
            this.pnlMain.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label6.Location = new System.Drawing.Point(11, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 21);
            this.label6.TabIndex = 20;
            this.label6.Text = "Search by keyword";
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtSearch.Location = new System.Drawing.Point(153, 36);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(340, 29);
            this.txtSearch.TabIndex = 19;
            this.txtSearch.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(11, 71);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(1048, 482);
            this.dgv.TabIndex = 18;
            this.dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(54)))), ((int)(((byte)(76)))));
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1070, 10);
            this.panel6.TabIndex = 0;
            // 
            // pnl1
            // 
            this.pnl1.BackColor = System.Drawing.Color.White;
            this.pnl1.Controls.Add(this.lblDateSaved);
            this.pnl1.Controls.Add(this.label48);
            this.pnl1.Controls.Add(this.lblLineJudges4);
            this.pnl1.Controls.Add(this.lblLineJudges3);
            this.pnl1.Controls.Add(this.lblLineJudges2);
            this.pnl1.Controls.Add(this.lblMatchTime);
            this.pnl1.Controls.Add(this.lblMatchDate);
            this.pnl1.Controls.Add(this.lblDivision);
            this.pnl1.Controls.Add(this.lblLineJudges1);
            this.pnl1.Controls.Add(this.lblScorer);
            this.pnl1.Controls.Add(this.lblReferee);
            this.pnl1.Controls.Add(this.lblMatchNumber);
            this.pnl1.Controls.Add(this.lblBeastOf);
            this.pnl1.Controls.Add(this.label13);
            this.pnl1.Controls.Add(this.label9);
            this.pnl1.Controls.Add(this.label8);
            this.pnl1.Controls.Add(this.label7);
            this.pnl1.Controls.Add(this.label5);
            this.pnl1.Controls.Add(this.label4);
            this.pnl1.Controls.Add(this.label3);
            this.pnl1.Controls.Add(this.label1);
            this.pnl1.Controls.Add(this.panel2);
            this.pnl1.Location = new System.Drawing.Point(24, 81);
            this.pnl1.Name = "pnl1";
            this.pnl1.Size = new System.Drawing.Size(349, 580);
            this.pnl1.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label1.Location = new System.Drawing.Point(11, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 21);
            this.label1.TabIndex = 20;
            this.label1.Text = "Best of";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(54)))), ((int)(((byte)(76)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(349, 10);
            this.panel2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label3.Location = new System.Drawing.Point(11, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 21);
            this.label3.TabIndex = 21;
            this.label3.Text = "Match Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label4.Location = new System.Drawing.Point(11, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 21);
            this.label4.TabIndex = 22;
            this.label4.Text = "Referee";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label5.Location = new System.Drawing.Point(11, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 21);
            this.label5.TabIndex = 23;
            this.label5.Text = "Scorer";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label7.Location = new System.Drawing.Point(11, 181);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 21);
            this.label7.TabIndex = 24;
            this.label7.Text = "Line Judges";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label8.Location = new System.Drawing.Point(11, 360);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 21);
            this.label8.TabIndex = 25;
            this.label8.Text = "Division";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label9.Location = new System.Drawing.Point(11, 405);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 21);
            this.label9.TabIndex = 26;
            this.label9.Text = "Match Date";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label13.Location = new System.Drawing.Point(11, 448);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(90, 21);
            this.label13.TabIndex = 30;
            this.label13.Text = "Match Time";
            // 
            // lblBeastOf
            // 
            this.lblBeastOf.AutoSize = true;
            this.lblBeastOf.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBeastOf.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblBeastOf.Location = new System.Drawing.Point(134, 34);
            this.lblBeastOf.Name = "lblBeastOf";
            this.lblBeastOf.Size = new System.Drawing.Size(19, 21);
            this.lblBeastOf.TabIndex = 31;
            this.lblBeastOf.Text = "3";
            // 
            // lblMatchNumber
            // 
            this.lblMatchNumber.AutoSize = true;
            this.lblMatchNumber.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatchNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblMatchNumber.Location = new System.Drawing.Point(134, 66);
            this.lblMatchNumber.Name = "lblMatchNumber";
            this.lblMatchNumber.Size = new System.Drawing.Size(19, 21);
            this.lblMatchNumber.TabIndex = 32;
            this.lblMatchNumber.Text = "3";
            // 
            // lblReferee
            // 
            this.lblReferee.AutoSize = true;
            this.lblReferee.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReferee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblReferee.Location = new System.Drawing.Point(134, 106);
            this.lblReferee.Name = "lblReferee";
            this.lblReferee.Size = new System.Drawing.Size(19, 21);
            this.lblReferee.TabIndex = 33;
            this.lblReferee.Text = "3";
            // 
            // lblScorer
            // 
            this.lblScorer.AutoSize = true;
            this.lblScorer.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScorer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblScorer.Location = new System.Drawing.Point(134, 145);
            this.lblScorer.Name = "lblScorer";
            this.lblScorer.Size = new System.Drawing.Size(19, 21);
            this.lblScorer.TabIndex = 34;
            this.lblScorer.Text = "3";
            // 
            // lblLineJudges1
            // 
            this.lblLineJudges1.AutoSize = true;
            this.lblLineJudges1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLineJudges1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblLineJudges1.Location = new System.Drawing.Point(134, 181);
            this.lblLineJudges1.Name = "lblLineJudges1";
            this.lblLineJudges1.Size = new System.Drawing.Size(19, 21);
            this.lblLineJudges1.TabIndex = 35;
            this.lblLineJudges1.Text = "3";
            // 
            // lblDivision
            // 
            this.lblDivision.AutoSize = true;
            this.lblDivision.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDivision.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblDivision.Location = new System.Drawing.Point(134, 360);
            this.lblDivision.Name = "lblDivision";
            this.lblDivision.Size = new System.Drawing.Size(19, 21);
            this.lblDivision.TabIndex = 36;
            this.lblDivision.Text = "3";
            // 
            // lblMatchDate
            // 
            this.lblMatchDate.AutoSize = true;
            this.lblMatchDate.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatchDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblMatchDate.Location = new System.Drawing.Point(134, 405);
            this.lblMatchDate.Name = "lblMatchDate";
            this.lblMatchDate.Size = new System.Drawing.Size(19, 21);
            this.lblMatchDate.TabIndex = 37;
            this.lblMatchDate.Text = "3";
            // 
            // lblMatchTime
            // 
            this.lblMatchTime.AutoSize = true;
            this.lblMatchTime.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatchTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblMatchTime.Location = new System.Drawing.Point(134, 448);
            this.lblMatchTime.Name = "lblMatchTime";
            this.lblMatchTime.Size = new System.Drawing.Size(19, 21);
            this.lblMatchTime.TabIndex = 38;
            this.lblMatchTime.Text = "3";
            // 
            // lblLineJudges2
            // 
            this.lblLineJudges2.AutoSize = true;
            this.lblLineJudges2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLineJudges2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblLineJudges2.Location = new System.Drawing.Point(134, 217);
            this.lblLineJudges2.Name = "lblLineJudges2";
            this.lblLineJudges2.Size = new System.Drawing.Size(19, 21);
            this.lblLineJudges2.TabIndex = 39;
            this.lblLineJudges2.Text = "3";
            // 
            // lblLineJudges3
            // 
            this.lblLineJudges3.AutoSize = true;
            this.lblLineJudges3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLineJudges3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblLineJudges3.Location = new System.Drawing.Point(134, 248);
            this.lblLineJudges3.Name = "lblLineJudges3";
            this.lblLineJudges3.Size = new System.Drawing.Size(19, 21);
            this.lblLineJudges3.TabIndex = 40;
            this.lblLineJudges3.Text = "3";
            // 
            // lblLineJudges4
            // 
            this.lblLineJudges4.AutoSize = true;
            this.lblLineJudges4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLineJudges4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblLineJudges4.Location = new System.Drawing.Point(134, 282);
            this.lblLineJudges4.Name = "lblLineJudges4";
            this.lblLineJudges4.Size = new System.Drawing.Size(19, 21);
            this.lblLineJudges4.TabIndex = 41;
            this.lblLineJudges4.Text = "3";
            // 
            // lblDateSaved
            // 
            this.lblDateSaved.AutoSize = true;
            this.lblDateSaved.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateSaved.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblDateSaved.Location = new System.Drawing.Point(134, 516);
            this.lblDateSaved.Name = "lblDateSaved";
            this.lblDateSaved.Size = new System.Drawing.Size(19, 21);
            this.lblDateSaved.TabIndex = 43;
            this.lblDateSaved.Text = "3";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label48.Location = new System.Drawing.Point(11, 516);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(107, 21);
            this.label48.TabIndex = 42;
            this.label48.Text = "Date modified";
            // 
            // pnl3
            // 
            this.pnl3.BackColor = System.Drawing.Color.White;
            this.pnl3.Controls.Add(this.lblTeamBResult);
            this.pnl3.Controls.Add(this.lblTeamBTimeout5);
            this.pnl3.Controls.Add(this.lblTeamBTimeout4);
            this.pnl3.Controls.Add(this.lblTeamBTimeout3);
            this.pnl3.Controls.Add(this.lblTeamBTimeout2);
            this.pnl3.Controls.Add(this.lblTeamBTimeout1);
            this.pnl3.Controls.Add(this.lblTeamBSet5);
            this.pnl3.Controls.Add(this.lblTeamBSet4);
            this.pnl3.Controls.Add(this.lblTeamBSet3);
            this.pnl3.Controls.Add(this.lblTeamBSet2);
            this.pnl3.Controls.Add(this.lblTeamBSet1);
            this.pnl3.Controls.Add(this.lblTeamBCoach);
            this.pnl3.Controls.Add(this.lblTeamBName);
            this.pnl3.Controls.Add(this.label62);
            this.pnl3.Controls.Add(this.label63);
            this.pnl3.Controls.Add(this.label64);
            this.pnl3.Controls.Add(this.label65);
            this.pnl3.Controls.Add(this.label66);
            this.pnl3.Controls.Add(this.label67);
            this.pnl3.Controls.Add(this.label68);
            this.pnl3.Controls.Add(this.label69);
            this.pnl3.Controls.Add(this.label70);
            this.pnl3.Controls.Add(this.label71);
            this.pnl3.Controls.Add(this.label72);
            this.pnl3.Controls.Add(this.label73);
            this.pnl3.Controls.Add(this.label74);
            this.pnl3.Controls.Add(this.panel4);
            this.pnl3.Location = new System.Drawing.Point(760, 81);
            this.pnl3.Name = "pnl3";
            this.pnl3.Size = new System.Drawing.Size(334, 498);
            this.pnl3.TabIndex = 55;
            // 
            // lblTeamBResult
            // 
            this.lblTeamBResult.AutoSize = true;
            this.lblTeamBResult.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBResult.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBResult.Location = new System.Drawing.Point(127, 456);
            this.lblTeamBResult.Name = "lblTeamBResult";
            this.lblTeamBResult.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBResult.TabIndex = 54;
            this.lblTeamBResult.Text = "3";
            // 
            // lblTeamBTimeout5
            // 
            this.lblTeamBTimeout5.AutoSize = true;
            this.lblTeamBTimeout5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBTimeout5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBTimeout5.Location = new System.Drawing.Point(164, 413);
            this.lblTeamBTimeout5.Name = "lblTeamBTimeout5";
            this.lblTeamBTimeout5.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBTimeout5.TabIndex = 53;
            this.lblTeamBTimeout5.Text = "3";
            // 
            // lblTeamBTimeout4
            // 
            this.lblTeamBTimeout4.AutoSize = true;
            this.lblTeamBTimeout4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBTimeout4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBTimeout4.Location = new System.Drawing.Point(164, 381);
            this.lblTeamBTimeout4.Name = "lblTeamBTimeout4";
            this.lblTeamBTimeout4.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBTimeout4.TabIndex = 52;
            this.lblTeamBTimeout4.Text = "3";
            // 
            // lblTeamBTimeout3
            // 
            this.lblTeamBTimeout3.AutoSize = true;
            this.lblTeamBTimeout3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBTimeout3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBTimeout3.Location = new System.Drawing.Point(164, 343);
            this.lblTeamBTimeout3.Name = "lblTeamBTimeout3";
            this.lblTeamBTimeout3.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBTimeout3.TabIndex = 51;
            this.lblTeamBTimeout3.Text = "3";
            // 
            // lblTeamBTimeout2
            // 
            this.lblTeamBTimeout2.AutoSize = true;
            this.lblTeamBTimeout2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBTimeout2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBTimeout2.Location = new System.Drawing.Point(164, 307);
            this.lblTeamBTimeout2.Name = "lblTeamBTimeout2";
            this.lblTeamBTimeout2.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBTimeout2.TabIndex = 50;
            this.lblTeamBTimeout2.Text = "3";
            // 
            // lblTeamBTimeout1
            // 
            this.lblTeamBTimeout1.AutoSize = true;
            this.lblTeamBTimeout1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBTimeout1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBTimeout1.Location = new System.Drawing.Point(164, 276);
            this.lblTeamBTimeout1.Name = "lblTeamBTimeout1";
            this.lblTeamBTimeout1.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBTimeout1.TabIndex = 49;
            this.lblTeamBTimeout1.Text = "3";
            // 
            // lblTeamBSet5
            // 
            this.lblTeamBSet5.AutoSize = true;
            this.lblTeamBSet5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBSet5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBSet5.Location = new System.Drawing.Point(164, 235);
            this.lblTeamBSet5.Name = "lblTeamBSet5";
            this.lblTeamBSet5.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBSet5.TabIndex = 48;
            this.lblTeamBSet5.Text = "3";
            // 
            // lblTeamBSet4
            // 
            this.lblTeamBSet4.AutoSize = true;
            this.lblTeamBSet4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBSet4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBSet4.Location = new System.Drawing.Point(164, 202);
            this.lblTeamBSet4.Name = "lblTeamBSet4";
            this.lblTeamBSet4.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBSet4.TabIndex = 47;
            this.lblTeamBSet4.Text = "3";
            // 
            // lblTeamBSet3
            // 
            this.lblTeamBSet3.AutoSize = true;
            this.lblTeamBSet3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBSet3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBSet3.Location = new System.Drawing.Point(164, 169);
            this.lblTeamBSet3.Name = "lblTeamBSet3";
            this.lblTeamBSet3.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBSet3.TabIndex = 46;
            this.lblTeamBSet3.Text = "3";
            // 
            // lblTeamBSet2
            // 
            this.lblTeamBSet2.AutoSize = true;
            this.lblTeamBSet2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBSet2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBSet2.Location = new System.Drawing.Point(164, 137);
            this.lblTeamBSet2.Name = "lblTeamBSet2";
            this.lblTeamBSet2.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBSet2.TabIndex = 45;
            this.lblTeamBSet2.Text = "3";
            // 
            // lblTeamBSet1
            // 
            this.lblTeamBSet1.AutoSize = true;
            this.lblTeamBSet1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBSet1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBSet1.Location = new System.Drawing.Point(164, 106);
            this.lblTeamBSet1.Name = "lblTeamBSet1";
            this.lblTeamBSet1.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBSet1.TabIndex = 44;
            this.lblTeamBSet1.Text = "3";
            // 
            // lblTeamBCoach
            // 
            this.lblTeamBCoach.AutoSize = true;
            this.lblTeamBCoach.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBCoach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBCoach.Location = new System.Drawing.Point(164, 72);
            this.lblTeamBCoach.Name = "lblTeamBCoach";
            this.lblTeamBCoach.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBCoach.TabIndex = 43;
            this.lblTeamBCoach.Text = "3";
            // 
            // lblTeamBName
            // 
            this.lblTeamBName.AutoSize = true;
            this.lblTeamBName.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamBName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamBName.Location = new System.Drawing.Point(164, 34);
            this.lblTeamBName.Name = "lblTeamBName";
            this.lblTeamBName.Size = new System.Drawing.Size(19, 21);
            this.lblTeamBName.TabIndex = 42;
            this.lblTeamBName.Text = "3";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label62.Location = new System.Drawing.Point(18, 456);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(52, 21);
            this.label62.TabIndex = 41;
            this.label62.Text = "Result";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label63.Location = new System.Drawing.Point(54, 413);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(78, 21);
            this.label63.TabIndex = 40;
            this.label63.Text = "Timeout 5";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label64.Location = new System.Drawing.Point(54, 381);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(79, 21);
            this.label64.TabIndex = 39;
            this.label64.Text = "Timeout 4";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label65.Location = new System.Drawing.Point(55, 343);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(78, 21);
            this.label65.TabIndex = 38;
            this.label65.Text = "Timeout 3";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label66.Location = new System.Drawing.Point(54, 307);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(78, 21);
            this.label66.TabIndex = 37;
            this.label66.Text = "Timeout 2";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label67.Location = new System.Drawing.Point(55, 276);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(76, 21);
            this.label67.TabIndex = 36;
            this.label67.Text = "Timeout 1";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label68.Location = new System.Drawing.Point(55, 235);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(43, 21);
            this.label68.TabIndex = 35;
            this.label68.Text = "Set 5";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label69.Location = new System.Drawing.Point(54, 202);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(44, 21);
            this.label69.TabIndex = 34;
            this.label69.Text = "Set 4";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label70.Location = new System.Drawing.Point(55, 169);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(43, 21);
            this.label70.TabIndex = 33;
            this.label70.Text = "Set 3";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label71.Location = new System.Drawing.Point(55, 137);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(43, 21);
            this.label71.TabIndex = 32;
            this.label71.Text = "Set 2";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label72.Location = new System.Drawing.Point(55, 106);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(41, 21);
            this.label72.TabIndex = 31;
            this.label72.Text = "Set 1";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label73.Location = new System.Drawing.Point(18, 72);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(53, 21);
            this.label73.TabIndex = 29;
            this.label73.Text = "Coach";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label74.Location = new System.Drawing.Point(18, 34);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(90, 21);
            this.label74.TabIndex = 28;
            this.label74.Text = "Team Name";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.SpringGreen;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(334, 10);
            this.panel4.TabIndex = 0;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(188)))), ((int)(((byte)(255)))));
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.Location = new System.Drawing.Point(943, 598);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(150, 62);
            this.btnBack.TabIndex = 55;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // pnl2
            // 
            this.pnl2.BackColor = System.Drawing.Color.White;
            this.pnl2.Controls.Add(this.lblTeamAResult);
            this.pnl2.Controls.Add(this.lblTeamATimeout5);
            this.pnl2.Controls.Add(this.lblTeamATimeout4);
            this.pnl2.Controls.Add(this.lblTeamATimeout3);
            this.pnl2.Controls.Add(this.lblTeamATimeout2);
            this.pnl2.Controls.Add(this.lblTeamATimeout1);
            this.pnl2.Controls.Add(this.lblTeamASet5);
            this.pnl2.Controls.Add(this.lblTeamASet4);
            this.pnl2.Controls.Add(this.lblTeamASet3);
            this.pnl2.Controls.Add(this.lblTeamASet2);
            this.pnl2.Controls.Add(this.lblTeamASet1);
            this.pnl2.Controls.Add(this.lblTeamACoach);
            this.pnl2.Controls.Add(this.lblTeamAName);
            this.pnl2.Controls.Add(this.label35);
            this.pnl2.Controls.Add(this.label36);
            this.pnl2.Controls.Add(this.label37);
            this.pnl2.Controls.Add(this.label38);
            this.pnl2.Controls.Add(this.label39);
            this.pnl2.Controls.Add(this.label40);
            this.pnl2.Controls.Add(this.label41);
            this.pnl2.Controls.Add(this.label42);
            this.pnl2.Controls.Add(this.label43);
            this.pnl2.Controls.Add(this.label44);
            this.pnl2.Controls.Add(this.label45);
            this.pnl2.Controls.Add(this.label46);
            this.pnl2.Controls.Add(this.label49);
            this.pnl2.Controls.Add(this.panel5);
            this.pnl2.Location = new System.Drawing.Point(401, 81);
            this.pnl2.Name = "pnl2";
            this.pnl2.Size = new System.Drawing.Size(334, 498);
            this.pnl2.TabIndex = 56;
            // 
            // lblTeamAResult
            // 
            this.lblTeamAResult.AutoSize = true;
            this.lblTeamAResult.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamAResult.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamAResult.Location = new System.Drawing.Point(127, 456);
            this.lblTeamAResult.Name = "lblTeamAResult";
            this.lblTeamAResult.Size = new System.Drawing.Size(19, 21);
            this.lblTeamAResult.TabIndex = 54;
            this.lblTeamAResult.Text = "3";
            // 
            // lblTeamATimeout5
            // 
            this.lblTeamATimeout5.AutoSize = true;
            this.lblTeamATimeout5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamATimeout5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamATimeout5.Location = new System.Drawing.Point(164, 413);
            this.lblTeamATimeout5.Name = "lblTeamATimeout5";
            this.lblTeamATimeout5.Size = new System.Drawing.Size(19, 21);
            this.lblTeamATimeout5.TabIndex = 53;
            this.lblTeamATimeout5.Text = "3";
            // 
            // lblTeamATimeout4
            // 
            this.lblTeamATimeout4.AutoSize = true;
            this.lblTeamATimeout4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamATimeout4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamATimeout4.Location = new System.Drawing.Point(164, 381);
            this.lblTeamATimeout4.Name = "lblTeamATimeout4";
            this.lblTeamATimeout4.Size = new System.Drawing.Size(19, 21);
            this.lblTeamATimeout4.TabIndex = 52;
            this.lblTeamATimeout4.Text = "3";
            // 
            // lblTeamATimeout3
            // 
            this.lblTeamATimeout3.AutoSize = true;
            this.lblTeamATimeout3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamATimeout3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamATimeout3.Location = new System.Drawing.Point(164, 343);
            this.lblTeamATimeout3.Name = "lblTeamATimeout3";
            this.lblTeamATimeout3.Size = new System.Drawing.Size(19, 21);
            this.lblTeamATimeout3.TabIndex = 51;
            this.lblTeamATimeout3.Text = "3";
            // 
            // lblTeamATimeout2
            // 
            this.lblTeamATimeout2.AutoSize = true;
            this.lblTeamATimeout2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamATimeout2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamATimeout2.Location = new System.Drawing.Point(164, 307);
            this.lblTeamATimeout2.Name = "lblTeamATimeout2";
            this.lblTeamATimeout2.Size = new System.Drawing.Size(19, 21);
            this.lblTeamATimeout2.TabIndex = 50;
            this.lblTeamATimeout2.Text = "3";
            // 
            // lblTeamATimeout1
            // 
            this.lblTeamATimeout1.AutoSize = true;
            this.lblTeamATimeout1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamATimeout1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamATimeout1.Location = new System.Drawing.Point(164, 276);
            this.lblTeamATimeout1.Name = "lblTeamATimeout1";
            this.lblTeamATimeout1.Size = new System.Drawing.Size(19, 21);
            this.lblTeamATimeout1.TabIndex = 49;
            this.lblTeamATimeout1.Text = "3";
            // 
            // lblTeamASet5
            // 
            this.lblTeamASet5.AutoSize = true;
            this.lblTeamASet5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamASet5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamASet5.Location = new System.Drawing.Point(164, 235);
            this.lblTeamASet5.Name = "lblTeamASet5";
            this.lblTeamASet5.Size = new System.Drawing.Size(19, 21);
            this.lblTeamASet5.TabIndex = 48;
            this.lblTeamASet5.Text = "3";
            // 
            // lblTeamASet4
            // 
            this.lblTeamASet4.AutoSize = true;
            this.lblTeamASet4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamASet4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamASet4.Location = new System.Drawing.Point(164, 202);
            this.lblTeamASet4.Name = "lblTeamASet4";
            this.lblTeamASet4.Size = new System.Drawing.Size(19, 21);
            this.lblTeamASet4.TabIndex = 47;
            this.lblTeamASet4.Text = "3";
            // 
            // lblTeamASet3
            // 
            this.lblTeamASet3.AutoSize = true;
            this.lblTeamASet3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamASet3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamASet3.Location = new System.Drawing.Point(164, 169);
            this.lblTeamASet3.Name = "lblTeamASet3";
            this.lblTeamASet3.Size = new System.Drawing.Size(19, 21);
            this.lblTeamASet3.TabIndex = 46;
            this.lblTeamASet3.Text = "3";
            // 
            // lblTeamASet2
            // 
            this.lblTeamASet2.AutoSize = true;
            this.lblTeamASet2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamASet2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamASet2.Location = new System.Drawing.Point(164, 137);
            this.lblTeamASet2.Name = "lblTeamASet2";
            this.lblTeamASet2.Size = new System.Drawing.Size(19, 21);
            this.lblTeamASet2.TabIndex = 45;
            this.lblTeamASet2.Text = "3";
            // 
            // lblTeamASet1
            // 
            this.lblTeamASet1.AutoSize = true;
            this.lblTeamASet1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamASet1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamASet1.Location = new System.Drawing.Point(164, 106);
            this.lblTeamASet1.Name = "lblTeamASet1";
            this.lblTeamASet1.Size = new System.Drawing.Size(19, 21);
            this.lblTeamASet1.TabIndex = 44;
            this.lblTeamASet1.Text = "3";
            // 
            // lblTeamACoach
            // 
            this.lblTeamACoach.AutoSize = true;
            this.lblTeamACoach.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamACoach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamACoach.Location = new System.Drawing.Point(164, 72);
            this.lblTeamACoach.Name = "lblTeamACoach";
            this.lblTeamACoach.Size = new System.Drawing.Size(19, 21);
            this.lblTeamACoach.TabIndex = 43;
            this.lblTeamACoach.Text = "3";
            // 
            // lblTeamAName
            // 
            this.lblTeamAName.AutoSize = true;
            this.lblTeamAName.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamAName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.lblTeamAName.Location = new System.Drawing.Point(164, 34);
            this.lblTeamAName.Name = "lblTeamAName";
            this.lblTeamAName.Size = new System.Drawing.Size(19, 21);
            this.lblTeamAName.TabIndex = 42;
            this.lblTeamAName.Text = "3";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label35.Location = new System.Drawing.Point(18, 456);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(52, 21);
            this.label35.TabIndex = 41;
            this.label35.Text = "Result";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label36.Location = new System.Drawing.Point(54, 413);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(78, 21);
            this.label36.TabIndex = 40;
            this.label36.Text = "Timeout 5";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label37.Location = new System.Drawing.Point(54, 381);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(79, 21);
            this.label37.TabIndex = 39;
            this.label37.Text = "Timeout 4";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label38.Location = new System.Drawing.Point(55, 343);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(78, 21);
            this.label38.TabIndex = 38;
            this.label38.Text = "Timeout 3";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label39.Location = new System.Drawing.Point(54, 307);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(78, 21);
            this.label39.TabIndex = 37;
            this.label39.Text = "Timeout 2";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label40.Location = new System.Drawing.Point(55, 276);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(76, 21);
            this.label40.TabIndex = 36;
            this.label40.Text = "Timeout 1";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label41.Location = new System.Drawing.Point(55, 235);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(43, 21);
            this.label41.TabIndex = 35;
            this.label41.Text = "Set 5";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label42.Location = new System.Drawing.Point(54, 202);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(44, 21);
            this.label42.TabIndex = 34;
            this.label42.Text = "Set 4";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label43.Location = new System.Drawing.Point(55, 169);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(43, 21);
            this.label43.TabIndex = 33;
            this.label43.Text = "Set 3";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label44.Location = new System.Drawing.Point(55, 137);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(43, 21);
            this.label44.TabIndex = 32;
            this.label44.Text = "Set 2";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label45.Location = new System.Drawing.Point(55, 106);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(41, 21);
            this.label45.TabIndex = 31;
            this.label45.Text = "Set 1";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label46.Location = new System.Drawing.Point(18, 72);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(53, 21);
            this.label46.TabIndex = 29;
            this.label46.Text = "Coach";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.label49.Location = new System.Drawing.Point(18, 34);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(90, 21);
            this.label49.TabIndex = 28;
            this.label49.Text = "Team Name";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(176)))), ((int)(((byte)(145)))));
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(334, 10);
            this.panel5.TabIndex = 0;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(188)))), ((int)(((byte)(255)))));
            this.btnDelete.FlatAppearance.BorderSize = 0;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(775, 598);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(150, 62);
            this.btnDelete.TabIndex = 57;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // frmMatches
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.ClientSize = new System.Drawing.Size(1116, 677);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.pnl2);
            this.Controls.Add(this.pnl3);
            this.Controls.Add(this.pnl1);
            this.Controls.Add(this.label2);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMatches";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMatches";
            this.Load += new System.EventHandler(this.frmMatches_Load);
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.pnl1.ResumeLayout(false);
            this.pnl1.PerformLayout();
            this.pnl3.ResumeLayout(false);
            this.pnl3.PerformLayout();
            this.pnl2.ResumeLayout(false);
            this.pnl2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel pnl1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblBeastOf;
        private System.Windows.Forms.Label lblDateSaved;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label lblLineJudges4;
        private System.Windows.Forms.Label lblLineJudges3;
        private System.Windows.Forms.Label lblLineJudges2;
        private System.Windows.Forms.Label lblMatchTime;
        private System.Windows.Forms.Label lblMatchDate;
        private System.Windows.Forms.Label lblDivision;
        private System.Windows.Forms.Label lblLineJudges1;
        private System.Windows.Forms.Label lblScorer;
        private System.Windows.Forms.Label lblReferee;
        private System.Windows.Forms.Label lblMatchNumber;
        private System.Windows.Forms.Panel pnl3;
        private System.Windows.Forms.Label lblTeamBResult;
        private System.Windows.Forms.Label lblTeamBTimeout5;
        private System.Windows.Forms.Label lblTeamBTimeout4;
        private System.Windows.Forms.Label lblTeamBTimeout3;
        private System.Windows.Forms.Label lblTeamBTimeout2;
        private System.Windows.Forms.Label lblTeamBTimeout1;
        private System.Windows.Forms.Label lblTeamBSet5;
        private System.Windows.Forms.Label lblTeamBSet4;
        private System.Windows.Forms.Label lblTeamBSet3;
        private System.Windows.Forms.Label lblTeamBSet2;
        private System.Windows.Forms.Label lblTeamBSet1;
        private System.Windows.Forms.Label lblTeamBCoach;
        private System.Windows.Forms.Label lblTeamBName;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Panel pnl2;
        private System.Windows.Forms.Label lblTeamAResult;
        private System.Windows.Forms.Label lblTeamATimeout5;
        private System.Windows.Forms.Label lblTeamATimeout4;
        private System.Windows.Forms.Label lblTeamATimeout3;
        private System.Windows.Forms.Label lblTeamATimeout2;
        private System.Windows.Forms.Label lblTeamATimeout1;
        private System.Windows.Forms.Label lblTeamASet5;
        private System.Windows.Forms.Label lblTeamASet4;
        private System.Windows.Forms.Label lblTeamASet3;
        private System.Windows.Forms.Label lblTeamASet2;
        private System.Windows.Forms.Label lblTeamASet1;
        private System.Windows.Forms.Label lblTeamACoach;
        private System.Windows.Forms.Label lblTeamAName;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnDelete;
    }
}